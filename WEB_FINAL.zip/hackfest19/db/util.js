
function insert(name, phone, pincode, lang)
{
    var sql_in = "INSERT INTO base (name, phn_no, pincode, language) VALUES ('" + name + "'," + phone + "," + pincode + ",'" + lang + "')";

    // var phone2 = req.body.phone2;
    // var locality = req.body.locality;
    // var state = req.body.state;
    // var district = req.body.district;
    // var subdiv = req.body.subdiv;
    // var address = req.body.addr;
    var flag = 0;
    con.query(sql_in, function(err, result){
        if(err)
        {
            flag= 0;
		console.log(flag);
            /*if(err == "ER_DUP_ENTRY")
                console.log("Duplicate Entry in base table");
            else
                console.log(err);*/
        }
        else
        {
            console.log("values inserted");
            flag= 1;
		console.log(flag);
        }
//	return callback(flag);
    });
}


module.exports.insert = insert;
//module.exports.fn = fn;
