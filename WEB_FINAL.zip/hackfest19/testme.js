var callme = require('./call.js');

callme.outboundCall(['+919836707352'], 1);