var mysql = require('mysql');

var con =  mysql.createConnection({
        host: "localhost",  //put your hostname
        user: "D_S",            //put your username here
        password: "sih19",      //put your user password here
        database: "SiH"
});

module.exports.con = con;
