import pickle
def save(file_name, obj):
    with open(file_name, 'wb') as fobj:
        pickle.dump(obj, fobj)

save('pickle_i.pickle', 0)